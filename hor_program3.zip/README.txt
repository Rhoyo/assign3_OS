Compile: gcc --std=gnu99 -o ./smallsh smallsh.c
Execute: smallsh
